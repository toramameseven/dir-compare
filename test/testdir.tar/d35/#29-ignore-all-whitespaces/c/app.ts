import   express = require( 'exp ress')  

import bodyParser = require('body-parser')
import * as configMiddleware from 'config-middleware'
import { config } from './config'
import { createLogger } from 'logger-lib'
import { LoggerMiddleware } from 'logger-middleware'
import { kafkaProducer } from './kafkaProducer'
import pkg = require('../package.json')
import { consumeStartSimulationEvent } from './coordinator/startSimulationConsumers'
import { consumeStopSimulationEvent } from './coordinator/stopSimulationConsumers'
import { metricsRegistry } from './metricsRegistry'
import { applyMetricsEndpoint, handleErrors, finalizeRequestMetrics } from 'metrics-lib/build/metricsMiddleware'
import * as sourceMaps from 'source-map-support'
import { lib } from 'metrics-lib'

sourceMaps.install()
lib.collectDefaultMetrics(metricsRegistry)

const logger = createLogger(config.serviceName, __filename)
const loggerMiddleware = new LoggerMiddleware(logger)

logger.info(`Starting ${config.serviceName} ${pkg.version}`);
logger.info(`Environment: ` + process.env.NODE_ENV);


consumeStart SimulationEvent ( ) 
consumeStopSimulationEvent()
kafkaProducer.connect()
    .then(() => logger.info(`Connected to Kafka on ${config.kafka.host}`))
    .catch(err => {
                 log		ger.error(err) ;
        process.exit(1)
    })


const app: express.Application = express()
const port = config.port

// Middleware
app.use(loggerMiddleware.logRequest())
app.use(bodyParser.json({ strict: false }))
configMiddleware.apply(app)
applyMetricsEndpoint(app, metricsRegistry)
app.use(loggerMiddleware.logResponse())
app.use(finalizeRequestMetrics())
app.use((err, req: express.Request, res: express.Response, next) => {
    logger.error(err)
    handleErrors(config.serviceName, res, metricsRegistry)
    res.status(500).send(err.toString())
})

app.listen(port, () => logger.info(`Listening on ${port}`))
